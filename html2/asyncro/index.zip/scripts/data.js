var movies_data = [
    {"Title":"The Simpsons Movie","Year":"2007","imdbID":"tt0462538","Type":"movie","Poster":"https://m.media-amazon.com/images/M/MV5BMTgxMDczMTA5N15BMl5BanBnXkFtZTcwMzk1MzMzMw@@._V1_SX300.jpg"},
    {"Title":"Scary Movie","Year":"2000","imdbID":"tt0175142","Type":"movie","Poster":"https://m.media-amazon.com/images/M/MV5BMGEzZjdjMGQtZmYzZC00N2I4LThiY2QtNWY5ZmQ3M2ExZmM4XkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg"},
    {"Title":"Avengers: Infinity War","Year":"2018","imdbID":9.8,"Type":"movie","Poster":"https://m.media-amazon.com/images/M/MV5BMjMxNjY2MDU1OV5BMl5BanBnXkFtZTgwNzY1MTUwNTM@._V1_SX300.jpg"},
    {"Title":" Epic Movie","Year":"2007","imdbID":8.4,"Type":"movie","Poster":"https://m.media-amazon.com/images/M/MV5BMTA3NDM5ODU3NzleQTJeQWpwZ15BbWU3MDgyMjgyNDE@._V1_SX300.jpg"},
    {"Title":"Scary Movie 4","Year":"2006","imdbID":9.5,"Type":"movie","Poster":"https://m.media-amazon.com/images/M/MV5BZmFkMzc2NTctN2U1Ni00MzE5LWJmMzMtYWQ4NjQyY2MzYmM1XkEyXkFqcGdeQXVyNTIzOTk5ODM@._V1_SX300.jpg"},
    {"Title":"The Lego Batman Movie","Year":"2017","imdbID":7.9,"Type":"series","Poster":"https://m.media-amazon.com/images/M/MV5BMTcyNTEyOTY0M15BMl5BanBnXkFtZTgwOTAyNzU3MDI@._V1_SX300.jpg"},
    {"Title":"Bee Movie","Year":"2007","imdbID":8.5,"Type":"movie","Poster":"https://m.media-amazon.com/images/M/MV5BMjE1MDYxOTA4MF5BMl5BanBnXkFtZTcwMDE0MDUzMw@@._V1_SX300.jpg"},
    {"Title":"Ultimate Avengers II","Year":"2006","imdbID":6,"Type":"movie","Poster":"https://m.media-amazon.com/images/M/MV5BZjI3MTI5ZTYtZmNmNy00OGZmLTlhNWMtNjZiYmYzNDhlOGRkL2ltYWdlL2ltYWdlXkEyXkFqcGdeQXVyNTAyODkwOQ@@._V1_SX300.jpg"},
   
];

localStorage.setItem("movies", JSON.stringify(movies_data));